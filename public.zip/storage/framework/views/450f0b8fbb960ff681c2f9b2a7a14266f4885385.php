


<?php $__env->startSection('content'); ?>
<div class="page-content py-3">

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card shadow">
                    <div class="card-header text-center"><?php echo e(__('Data Absen')); ?></div>
                    <div class="card-body">
                        <div class="desc">
                            <p>Project : <?php echo e(Auth::user()->project->nama); ?></p>
                            <p>Employee : <?php echo e(Auth::user()->name); ?></p>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-striped text-center">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Date</th>
                                        <th scope="col">Day</th>
                                        <th scope="col">In</th>
                                        <th scope="col">Out</th>
                                        <th scope="col">Total</th>
                                        <th scope="col">Activity</th>
                                        <th scope="col">Site</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <th scope="row"><?php echo e($key + 1); ?></th>
                                        <td><?php echo e($value->date); ?></td>
                                        <td><?php echo e($value->day); ?></td>
                                        <td><?php echo e($value->time_in); ?></td>
                                        <td><?php echo e($value->time_out); ?></td>
                                        <td><?php echo e($value->total_hours); ?></td>
                                        <td><?php echo e($value->activity); ?></td>
                                        <td><?php echo e($value->site_name); ?></td>
                                        <td class="d-flex justify-content-center">
                                            <a href="<?php echo e(route('data.edit', ['data' => $value->id])); ?>"
                                                class="btn btn-dark mr-2"><i class="fas fa-edit"></i></a>
                                            <a href="" class="btn btn-dark" onclick="event.preventDefault();
                                                    document.getElementById('delete').submit();"><i
                                                    class="fas fa-trash"></i></a>
                                            <form id="delete"
                                                action="<?php echo e(route('data.destroy', ['data' => $value->id])); ?>"
                                                method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="9">No Data</td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                            <div class="table-responsive">
                            </div>
                        </div>
                        <button type="button" class="btn text-white" data-toggle="modal" data-target="#exampleModal"
                            style="background-color: black">
                            Print Data
                        </button>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--//page-content-->

<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Range Time</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label for="bulan">Month</label>
                    <select class="form-control" id="bulan">
                        <option value="">--Choose--</option>
                        <option value="1">January</option>
                        <option value="2">February</option>
                        <option value="3">March</option>
                        <option value="4">April</option>
                        <option value="5">May</option>
                        <option value="6">June</option>
                        <option value="7">July</option>
                        <option value="8">August</option>
                        <option value="9">September</option>
                        <option value="10">October</option>
                        <option value="11">November</option>
                        <option value="12">December</option>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <a class="btn text-white" style="background-color: black"
                    onclick="this.href='/cpdf/'+ document.getElementById('bulan').value " target="_blank">Print</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portal-absen\resources\views/user/data.blade.php ENDPATH**/ ?>