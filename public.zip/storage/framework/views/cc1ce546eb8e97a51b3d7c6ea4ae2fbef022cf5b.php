

<?php $__env->startSection('content'); ?>
<div class="card shadow mb-4">
    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
        <h6 class="m-0 font-weight-bold text-danger">Holiday Data</h6>
    </div>
    <!-- Card Body -->
    <div class="card-body">
        <form action="<?php echo e(route('holiday.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="date">Date</label>
                <input type="date" class="form-control" id="date" name="date" onchange="ubahTanggal()">
            </div>
            <div class="form-group">
                <label for="day">Day</label>
                <input type="text" class="form-control" id="day" name="day" readonly>
            </div>
            <button type="submit" class="btn btn-danger col-md-12">Save</button>
        </form>
    </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startPush('javascript'); ?>
    <script src="https://momentjs.com/downloads/moment.js"></script>
    <script>
        function ubahTanggal() {
            let mydate = document.querySelector("#date").value;
            let weekDayName = moment(mydate).format('dddd');
            document.querySelector('#day').value = weekDayName;
        }
    </script>
    <?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\log-jarvis\resources\views/admin/holiday/create.blade.php ENDPATH**/ ?>