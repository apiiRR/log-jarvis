


<?php $__env->startSection('content'); ?>
<div class="page-content py-3">
    <div class="container-fluid">
        <ul class="features-tab nav nav-pills justify-content-center" id="features-tab" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" id="feature-tab-1" data-toggle="tab" href="#feature-1" role="tab"
                    aria-controls="feature-1" aria-selected="true"><span>Form Absen</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="feature-tab-2" data-toggle="tab" href="#feature-2" role="tab"
                    aria-controls="feature-2" aria-selected="false">Data Absen</a>
            </li>
        </ul>
    </div>

    <div class="container">
        <div class="features-tab-content tab-content" id="features-tab-content">
            <div class="feature-1-pane tab-pane fade show active" id="feature-1" role="tabpanel"
                aria-labelledby="feature-tab-1">
                <section class="auth-section login-section text-center py-5">
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-md-8">
                                <div class="card shadow">
                                    <div class="card-header text-center"><?php echo e(__('Form Absen')); ?></div>
                                    <?php if(session('success')): ?>
                                    <div class="alert alert-success" role="alert">
                                        <?php echo e(session('success')); ?>

                                    </div>
                                    <?php endif; ?>
                                    <div class="card-body">
                                        <form action="<?php echo e(route('data.store')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group">
                                                <label for="nama">Name</label>
                                                <input type="text" class="form-control" id="nama"
                                                    value="<?php echo e(Auth::user()->name); ?>" readonly>
                                                <input type="text" value="<?php echo e(Auth::user()->id); ?>" name="name" readonly
                                                    hidden>
                                            </div>
                                            <div class="form-row">
                                                <div class="form-group col-md-6">
                                                    <label for="tanggal">Date</label>
                                                    <input type="date" class="tanggal form-control" id="tanggal"
                                                        name="date" readonly>
                                                </div>
                                                <div class="form-group col-md-6">
                                                    <label for="hari">Day</label>
                                                    <input type="text" class="form-control" id="hari" name="day"
                                                        readonly>
                                                </div>
                                            </div>
                                            <div class="form-row">
                                                <div class="form-group col-md-6">
                                                    <label for="time-in">Time In</label>
                                                    <input type="time" class="form-control" id="time-in" name="time_in">
                                                </div>
                                                <div class="form-group col-md-6">
                                                    <label for="time-out">Time Out</label>
                                                    <input type="time" class="form-control" id="time-out"
                                                        name="time_out" onchange="totalJam()">
                                                </div>
                                            </div>
                                            <div class="form-row">
                                                <div class="form-group col-md-6">
                                                    <label for="total">Total Hours</label>
                                                    <input type="text" class="form-control" id="total"
                                                        name="total_hours" readonly>
                                                </div>
                                                <div class="form-group col-md-6">
                                                    <label for="site">Site Name</label>
                                                    <input type="text" class="form-control" id="site" name="site_name">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label for="activity">Activity</label>
                                                <input type="text" class="form-control" id="activity" name="activity">
                                            </div>
                                            <button type="submit" class="btn btn-primary col-md-12">Simpan</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--//container-->
                </section>
                <!--//auth-section-->
            </div>
            <div class="feature-2-pane tab-pane fade py-5" id="feature-2" role="tabpanel"
                aria-labelledby="feature-tab-2">
                <section class="auth-section login-section">
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-md-12">
                                <div class="card shadow">
                                    <div class="card-header text-center"><?php echo e(__('Data Absen')); ?></div>
                                    <?php if(session('success')): ?>
                                    <div class="alert alert-success" role="alert">
                                        <?php echo e(session('success')); ?>

                                    </div>
                                    <?php endif; ?>
                                    <div class="card-body">
                                        <div class="desc">
                                            <p>Project : <?php echo e(Auth::user()->project->nama); ?></p>
                                            <p>Employee : <?php echo e(Auth::user()->name); ?></p>
                                        </div>
                                        <div class="table-responsive">
                                            <table class="table table-striped text-center">
                                                <thead>
                                                    <tr>
                                                        <th scope="col">#</th>
                                                        <th scope="col">Date</th>
                                                        <th scope="col">Day</th>
                                                        <th scope="col">In</th>
                                                        <th scope="col">Out</th>
                                                        <th scope="col">Total</th>
                                                        <th scope="col">Activity</th>
                                                        <th scope="col">Site</th>
                                                        <th scope="col">Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__empty_1 = true; $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <tr>
                                                        <th scope="row"><?php echo e($key + 1); ?></th>
                                                        <td><?php echo e($value->date); ?></td>
                                                        <td><?php echo e($value->day); ?></td>
                                                        <td><?php echo e($value->time_in); ?></td>
                                                        <td><?php echo e($value->time_out); ?></td>
                                                        <td><?php echo e($value->total_hours); ?></td>
                                                        <td><?php echo e($value->activity); ?></td>
                                                        <td><?php echo e($value->site_name); ?></td>
                                                        <td class="d-flex justify-content-center">
                                                            <a href="" class="btn btn-danger" onclick="event.preventDefault();
                                                     document.getElementById('delete').submit();"><i
                                                                    class="fas fa-trash"></i></a>
                                                            <form id="delete"
                                                                action="<?php echo e(route('data.destroy', ['data' => $value->id])); ?>"
                                                                method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>
                                                                
                                                            </form>
                                                        </td>
                                                    </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <tr>
                                                        <td colspan="9">No Data</td>
                                                    </tr>
                                                    <?php endif; ?>
                                                </tbody>
                                            </table>
                                            <div class="table-responsive">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--//container-->
                </section>
                <!--//auth-section-->
            </div>
            <!--//feature-2-pane-->
        </div>
    </div>
    <!--//container-->
</div>
<!--//page-content-->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('javascript'); ?>
<script src="https://momentjs.com/downloads/moment.js"></script>
<script>
    function ubahTanggal() {
        let mydate = new Date;
        var date = mydate.toJSON().slice(0, 10);
        var nDate = date.slice(0, 4) + '-' +
            date.slice(5, 7) + '-' +
            date.slice(8, 10);
        let weekDayName = moment(mydate).format('dddd');
        document.querySelector('#tanggal').value = nDate;
        document.querySelector('#hari').value = weekDayName;
        // console.log(nDate);
    }

    ubahTanggal();

    function totalJam() {
        let jamAwal = document.querySelector("#time-in").value;
        let jamAkhir = document.querySelector("#time-out").value;

        let hours = jamAkhir.split(':')[0] - jamAwal.split(':')[0];
        let minutes = jamAkhir.split(':')[1] - jamAwal.split(':')[1];

        if (jamAwal <= "12:00" && jamAkhir >= "13:00") {
            a = 1;
        } else {
            a = 0;
        }
        minutes = minutes.toString().length < 2 ? '0' + minutes : minutes;
        if (minutes < 0) {
            hours--;
            minutes = 60 + minutes;
        }
        hours = hours.toString().length < 2 ? '0' + hours : hours;
        document.querySelector('#total').value = hours - a + ':' + minutes;
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\log-jarvis\resources\views/user/index.blade.php ENDPATH**/ ?>