

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header text-center"><?php echo e(__('Form Absen')); ?></div>
                <?php if(session('success')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('success')); ?>

                </div>
                <?php endif; ?>
                <div class="card-body">
                    <form action="<?php echo e(route('data.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="nama">Name</label>
                            <input type="text" class="form-control" id="nama" value="<?php echo e(Auth::user()->name); ?>" readonly>
                            <input type="text" value="<?php echo e(Auth::user()->id); ?>" name="name" readonly hidden>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="tanggal">Date</label>
                                <input type="date" class="tanggal form-control"
                                    id="tanggal" name="date" onchange="ubahTanggal()">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="hari">Day</label>
                                <input type="text" class="form-control" id="hari" name="day" readonly>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="time-in">Time In</label>
                                <input type="time" class="form-control" id="time-in" name="time in">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="time-out">Time Out</label>
                                <input type="time" class="form-control" id="time-out" name="time out"
                                    onchange="totalJam()">
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="total">Total Hours</label>
                                <input type="text" class="form-control" id="total" name="total hours" readonly>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="site">Site Name</label>
                                <input type="text" class="form-control" id="site" name="site name">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="activity">Activity</label>
                            <input type="text" class="form-control" id="activity" name="activity">
                        </div>
                        <button type="submit" class="btn btn-primary col-md-12">Simpan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('javascript'); ?>
<script src="https://momentjs.com/downloads/moment.js"></script>
<script>

    function ubahTanggal() {
        let mydate = document.querySelector("#tanggal").value;
        let weekDayName =  moment(mydate).format('dddd');
        document.querySelector('#hari').value = weekDayName;
    }


    function totalJam() {
        let jamAwal = document.querySelector("#time-in").value;
        let jamAkhir = document.querySelector("#time-out").value;

        let hours = jamAkhir.split(':')[0] - jamAwal.split(':')[0];
        let minutes = jamAkhir.split(':')[1] - jamAwal.split(':')[1];

        if (jamAwal <= "12:00" && jamAkhir >= "13:00") {
            a = 1;
        } else {
            a = 0;
        }
        minutes = minutes.toString().length < 2 ? '0' + minutes : minutes;
        if (minutes < 0) {
            hours--;
            minutes = 60 + minutes;
        }
        hours = hours.toString().length < 2 ? '0' + hours : hours;
        document.querySelector('#total').value = hours - a + ':' + minutes;
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\log-jarvis\resources\views/data/data.blade.php ENDPATH**/ ?>