

<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if(session('success')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>
    <div class="div-box">
        <div class="User-img">
            <img src="<?php echo e(asset('admin/img/undraw_profile.svg')); ?>">
        </div>
        <h3 class="User-name">Name : <?php echo e(Auth::user()->name); ?></h3>
        <h4 class="designation">Email : <?php echo e(Auth::user()->email); ?></h4>
        <div class="contact-btn">
            <a href="<?php echo e(route('profile.show', ['profile' => Auth::user()->id])); ?>" class="btn btn-success">Update</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\log-jarvis\resources\views/admin/profile/index.blade.php ENDPATH**/ ?>