

<?php $__env->startSection('content'); ?>
<div class="card shadow mb-4">
    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
        <h6 class="m-0 font-weight-bold" style="color: black;">Overall Absence Data</h6>
    </div>
    <!-- Card Body -->
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped text-center" style="color: black">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Name</th>
                        <th scope="col">Project</th>
                        <th scope="col">Date</th>
                        <th scope="col">Day</th>
                        <th scope="col">In</th>
                        <th scope="col">Out</th>
                        <th scope="col">Total</th>
                        <th scope="col">Activity</th>
                        <th scope="col">Site</th>
                        <th scope="col">Remark</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <th scope="row"><?php echo e($key + 1); ?></th>
                        <td><?php echo e($value->user->name); ?></td>
                        <td><?php echo e($value->user->project->nama); ?></td>
                        <td><?php echo e($value->date); ?></td>
                        <td><?php echo e($value->day); ?></td>
                        <td><?php echo e($value->time_in); ?></td>
                        <td><?php echo e($value->time_out); ?></td>
                        <td><?php echo e($value->total_hours); ?></td>
                        <td><?php echo e($value->activity); ?></td>
                        <td><?php echo e($value->site_name); ?></td>
                        <td><?php echo e($value->remark); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="10">No Data</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
                </tbody>
            </table>
            <div class="table-responsive">
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portal-absen\resources\views/admin/index.blade.php ENDPATH**/ ?>